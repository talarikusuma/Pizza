create table admin_table(
username varchar2(20),
password varchar2(20));

create table book_order(index1 number(3),
orderid number primary key,
orderby varchar2(20),
bookcopies number(4),
total numeric(5,2),
payment varchar2(20),
status varchar2(20),
orderdate timestamp);

create table ordered_books(
orderid foreign key references book_order(orderid),
index1 number(4),
booktitle varchar2(30),
author varchar2(30),
price numeric(5,2),
quantity number(3),
subtotal numeric(5,2));

create sequence index1_sequence increment by 1;

SQL> create table order_overview(
orderid references book_order(orderid),
recipientname varchar2(20),
recipientnumber varchar2(20),
shipto varchar2(30));




SQL> desc book_order;
 Name                                      Null?    Type
 ----------------------------------------- -------- ------------------------

 INDEX1                                             NUMBER(3)
 ORDERID                                   NOT NULL NUMBER
 ORDERBY                                            VARCHAR2(20)
 BOOKCOPIES                                         NUMBER(4)
 TOTAL                                              NUMBER(5,2)
 PAYMENT                                            VARCHAR2(20)
 STATUS                                             VARCHAR2(20)
 ORDERDATE                                          TIMESTAMP(6)
 
SQL> insert into book_order values(1,45,'Tom Eager',3,138.32,'Cash on Delivery',
'Shipping',timestamp '2017-06-03 15:11:46');

1 row created.

SQL> insert into book_order values(2,44,'Jane Billy',3,210.99,'Cash on Delivery'
,'Processing',timestamp '2017-05-18 10:29:00');

1 row created.

SQL> insert into book_order values(3,43,'Carol Beck',1,54.00,'Cash on Delivery',
'Shipping',timestamp '2017-05-18 09:57:47');

1 row created.

SQL> insert into book_order values(4,42,'David Smith',2,68.90,'Cash on Delivery'
,'Completed',timestamp '2017-05-17 15:44:30');

1 row created.

SQL> insert into book_order values(5,41,'Alice Burne',4,244.99,'Cash on Delivery
','Completed',timestamp '2017-05-17 15:37:32');

1 row created.

SQL> commit;

Commit complete.

SQL> desc order_overview;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------

 ORDERID                                            NUMBER
 RECIPIENTNAME                                      VARCHAR2(20)
 RECIPIENTNUMBER                                    VARCHAR2(20)
 SHIPTO                                             VARCHAR2(30)

SQL> insert into order_overview values(45,'George Beck','9704983672','34 BakerST
 NY USA');

1 row created.

SQL> insert into order_overview values(44,'Jane Smith','9736478925','67 Ferris W
D USA');

1 row created.

SQL> insert into order_overview values(43,'Brune Mark','8347653920','84 Dennis M
exico');

1 row created.

SQL> insert into order_overview values(42,'Eager David','8764938265','63 Louis C
hicago');

1 row created.

SQL> insert into order_overview values(41,'Reinhold Alice','8392045671','47 Marl
in Fransisco');

1 row created.