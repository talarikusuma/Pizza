create table admin_table(
username varchar2(20),
password varchar2(20));

create table book_order(index1 number(3),
orderid number primary key,
orderby varchar2(20),
bookcopies number(4),
total numeric(5,2),
payment varchar2(20),
status varchar2(20),
orderdate timestamp);

create table ordered_books(
orderid foreign key references book_order(orderid),
index1 number(4),
booktitle varchar2(30),
author varchar2(30),
price numeric(5,2),
quantity number(3),
subtotal numeric(5,2));

create sequence index1_sequence increment by 1;

SQL> create table order_overview(
orderid references book_order(orderid),
recipientname varchar2(20),
recipientnumber varchar2(20),
shipto varchar2(30));
