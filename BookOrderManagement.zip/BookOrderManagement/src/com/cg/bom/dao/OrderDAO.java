package com.cg.bom.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.BookListbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Orderbean;
import com.cg.bom.bean.Viewbean;
import com.cg.bom.connection.OrderConnection;
import com.cg.bom.exception.OrderException;

@SuppressWarnings("resource")
public class OrderDAO implements IOrderDAO {

	static Logger logger = Logger.getRootLogger();
	public OrderDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	}
	
	
	/**---------------------ADMIN LOGIN----------------------*
	 * Method name			:ValidLogin						*
	 * Return Type			:boolean						*
	 * Throws				:OrderException					*
	 * Description			:Validate admin					*
	 * Author				:Capgemini						*
	 * Creation Date		:24/06/2019						*
	 * ----------------------------------------------------**/
	@Override
	public boolean ValidLogin(Adminbean adminBean) throws OrderException{
		
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
		String username = adminBean.getUsername();
		String password = adminBean.getPassword();
		preparedStatement = connection.prepareStatement(QueryMapper.VALIDATE_ADMIN_QUERY);
		 resultSet = preparedStatement.executeQuery();
		//System.out.println(rs);
		while(resultSet.next())
		{
			if(resultSet.getString(1).equals(username)&&resultSet.getString(2).equals(password))
			{
				return true;
			}
		}
		return false;
		}catch(SQLException e)
		{
			logger.error("Invalid username or password");
			throw new OrderException(e.getMessage());
		}
	}
	
	
	/**-------------------ORDER LISTING---------------------*
	 * Method name			:Listing						*
	 * Return Type			:List<Orderbean>				*
	 * Throws				:OrderException					*
	 * Description			:display list of orders			*
	 * Author				:Capgemini						*
	 * Creation Date		:24/06/2019						*
	 * -----------------------------------------------------
	 * @throws SQLException */

	@Override
	public List<Orderbean> Listing() throws OrderException, SQLException {
		// TODO Auto-generated method stub
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
		preparedStatement = connection.prepareStatement(QueryMapper.ORDER_LISTING_QUERY);
		resultSet = preparedStatement.executeQuery();
		//System.out.println(resultSet);
		List<Orderbean> customList = new ArrayList<Orderbean>();
		while(resultSet.next())
		{
			Orderbean orderbean = new Orderbean();
			orderbean.setIndex(resultSet.getInt(1));
			orderbean.setOrderid(resultSet.getInt(2));
			orderbean.setOrderby(resultSet.getString(3));
			orderbean.setBookcopies(resultSet.getInt(4));
			orderbean.setTotal(resultSet.getDouble(5));
			orderbean.setPaymethod(resultSet.getString(6));
			orderbean.setStatus(resultSet.getString(7));
			orderbean.setOrderdate(resultSet.getTimestamp(8));
			 customList.add(orderbean);
			//System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
		}
			resultSet.close();
			preparedStatement.close();
			connection.close();
		return customList;
	
	}catch(SQLException e)
	{
		logger.error("Could not find the list");
		throw new OrderException(e.getMessage());
	}
		finally {
			resultSet.close();
			preparedStatement.close();
			connection.close();
		}
	}
	
	
	/**----------------ORDER OVERVIEW-----------------------*
	 * Method name			:orderoverview					*
	 * Return Type			:Viewbean						*
	 * Throws				:OrderException					*
	 * Description			:display ordered details		*
	 * Author				:Capgemini						*
	 * Creation Date		:24/06/2019						*
	 * -----------------------------------------------------
	 * @throws SQLException */
	@Override
	public Viewbean orderoverview(int orderId) throws OrderException, SQLException{
		// TODO Auto-generated method stub
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Viewbean viewbean = null;
		try {
		preparedStatement = connection.prepareStatement(QueryMapper.OVERVIEW_QUERY);
		preparedStatement.setInt(1, orderId);
		resultSet = preparedStatement.executeQuery();
		if(resultSet.next())
		{
			viewbean = new Viewbean();
			viewbean.setOrderby(resultSet.getString(1));
			viewbean.setBookcopies(resultSet.getInt(2));
			viewbean.setTotal(resultSet.getDouble(3));
			viewbean.setRecipientname(resultSet.getString(4));
			viewbean.setRecipientnumber(resultSet.getString(5));
			viewbean.setShipto(resultSet.getString(6));
			viewbean.setPayment(resultSet.getString(7));
			viewbean.setStatus(resultSet.getString(8));
			viewbean.setOrderdate(resultSet.getTimestamp(9));
		}
		
		return viewbean;
		}
		catch(SQLException e) {
			logger.error("Could not find the details.");
			throw new OrderException(e.getMessage());
		}
		finally {
			resultSet.close();
			preparedStatement.close();
			connection.close();
		}
	}

	
	/**----------------ORDERED BOOKS------------------------*
	 * Method name			:orderbooks						*
	 * Return Type			:List<Bookbean>					*
	 * Throws				:OrderException					*
	 * Description			:display book details			*
	 * Author				:Capgemini						*
	 * Creation Date		:24/06/2019						*
	 * -----------------------------------------------------
	 * @throws SQLException **/

	
	@Override
	public List<Bookbean> orderbooks(int orderid) throws OrderException, SQLException {
		// TODO Auto-generated method stub
		double total = 0.0;
		int totalQuantity = 0;
		Connection connection = OrderConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Bookbean bookBean = null;
		List<Bookbean> booklist = new ArrayList<Bookbean>();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.BOOK_LIST_QUERY);
			preparedStatement.setInt(1, orderid);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				bookBean = new Bookbean();
				bookBean.setIndex(resultSet.getInt(1));
				bookBean.setBooktitle(resultSet.getString(2));
				bookBean.setAuthor(resultSet.getString(3));
				bookBean.setPrice(resultSet.getDouble(4));
				bookBean.setQuantity(resultSet.getInt(5));
				bookBean.setSubtotal(resultSet.getDouble(6));
				bookBean.setTotal(total);
				booklist.add(bookBean);
				total = total + resultSet.getDouble(6);
				totalQuantity = totalQuantity + resultSet.getInt(5);
			}
			preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_BOOKORDER_QUERY);
			preparedStatement.setDouble(1, total);
			preparedStatement.setInt(2, totalQuantity);
			preparedStatement.setInt(3, orderid);
			resultSet = preparedStatement.executeQuery();
			
		} 
		catch (SQLException e) {
			logger.error("Could not add the book to list");
			throw new OrderException("Retrieving the book details failed!");
		}
		finally {
			resultSet.close();
			preparedStatement.close();
			connection.close();
		}
		return booklist;
	}
	
	/**------------------ADD BOOKS--------------------------
	 * Method name			:addbooks						*
	 * Return Type			:Bookbean						*
	 * Throws				:OrderException					*
	 * Description			:add books 						*
	 * Author				:Capgemini						*
	 * Creation Date		:24/06/2019						*
	 * -----------------------------------------------------
	 * @throws SQLException **/
	@Override
	public Bookbean addbook(int orderId,int choice,Bookbean bookBean) throws OrderException, SQLException {
		// TODO Auto-generated method stub
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
		preparedStatement = connection.prepareStatement(QueryMapper.BOOK_CATALOG_QUERY+" where index2=?");
		preparedStatement.setInt(1, choice);
		resultSet = preparedStatement.executeQuery();
		if(resultSet.next())
		{
			bookBean.setBooktitle(resultSet.getString(2));
			bookBean.setAuthor(resultSet.getString(3));
			bookBean.setPrice(resultSet.getDouble(4));
		}
		bookBean.setSubtotal(bookBean.getPrice()*bookBean.getQuantity());
		preparedStatement = connection.prepareStatement(QueryMapper.INSERT_BOOK_QUERY);
		preparedStatement.setInt(1, orderId);
		preparedStatement.setString(2, bookBean.getBooktitle());
		preparedStatement.setString(3, bookBean.getAuthor());
		preparedStatement.setDouble(4, bookBean.getPrice());
		preparedStatement.setInt(5, bookBean.getQuantity());
		preparedStatement.setDouble(6, bookBean.getSubtotal());
		resultSet = preparedStatement.executeQuery();
		}
		catch(SQLException e) {
			logger.error("No order id found");
			throw new OrderException(e.getMessage());
		}
		finally {
			resultSet.close();
			preparedStatement.close();
			connection.close();
		}
		return bookBean;
	}
	
	
	/**------------------VIEW BOOKS--------------------------
	 * Method name			:getbooks						*
	 * Return Type			:List<BookListbean>				*
	 * Throws				:OrderException					*
	 * Description			:retrive books					*
	 * Author				:Capgemini						*
	 * Creation Date		:24/06/2019						*
	 * -----------------------------------------------------
	 * @throws SQLException **/
	@Override
	public List<BookListbean> getbooks() throws OrderException, SQLException {
		// TODO Auto-generated method stub
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<BookListbean> bookCatalog = new ArrayList<BookListbean>();
		try {
		preparedStatement = connection.prepareStatement(QueryMapper.BOOK_CATALOG_QUERY);
		resultSet = preparedStatement.executeQuery();
		while(resultSet.next())
		{
			BookListbean booklistbean = new BookListbean();
			booklistbean.setIndex(resultSet.getInt(1));
			booklistbean.setBooktitle(resultSet.getString(2));
			booklistbean.setAuthor(resultSet.getString(3));
			booklistbean.setPrice(resultSet.getDouble(4));
			bookCatalog.add(booklistbean);
		}
		}
		catch(SQLException e)
		{
			logger.error("The list is empty");
			throw new OrderException("The list is empty");
		}
		finally {
			resultSet.close();
			preparedStatement.close();
			connection.close();
		}
		return bookCatalog;
	}

	 
	/**------------------DELETE BOOKS--------------------------
	 * Method name			:deletetbooks					*
	 * Return Type			:int							*
	 * Throws				:OrderException					*
	 * Description			:delete books					*
	 * Author				:Capgemini						*
	 * Creation Date		:24/06/2019						*
	 * -----------------------------------------------------
	 * @throws SQLException **/
	@Override
	public int deletebook(int orderid) throws OrderException, SQLException {
		// TODO Auto-generated method stub
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement = null;
		int delete=0;
		try {
		int viewDelete=0,orderDelete=0,bookDelete=0;
		preparedStatement = connection.prepareStatement(QueryMapper.DELETE_ORDERVIEW_QUERY);
		preparedStatement.setInt(1, orderid);
		viewDelete=preparedStatement.executeUpdate();
		preparedStatement = connection.prepareStatement(QueryMapper.DELETE_ORDERBOOKS_QUERY);
		preparedStatement.setInt(1, orderid);
		orderDelete=preparedStatement.executeUpdate();
		preparedStatement = connection.prepareStatement(QueryMapper.DELETE_BOOKORDER_QUERY);
		preparedStatement.setInt(1, orderid);
		bookDelete=preparedStatement.executeUpdate();
		
		if(viewDelete!=0&&orderDelete!=0&&bookDelete!=0)
			delete=1;
		else
			delete=0;
		}
		catch(SQLException e)
		{
			logger.error("The order could not be deleted");
			throw new OrderException(e.getMessage());
		}
		finally {
			preparedStatement.close();
			connection.close();
		}
		return delete;
	}
	
	
	/**------------------FIND ORDER--------------------------
	 * Method name			:findorder						*
	 * Return Type			:boolean						*
	 * Throws				:OrderException					*
	 * Description			:search ordered details			*
	 * Author				:Capgemini						*
	 * Creation Date		:24/06/2019						*
	 * -----------------------------------------------------
	 * @throws SQLException **/
	@Override
	public boolean findorder(int orderid) throws OrderException, SQLException {
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		boolean found=true;
		try {
		preparedStatement = connection.prepareStatement("select * from book_order where orderid=?");
		preparedStatement.setInt(1, orderid);
		resultSet = preparedStatement.executeQuery();
		if(resultSet.next())
		{
			//System.out.println(resultSet.getString(2));
			found=true;
		}
		else
			found=false;
		}
		catch(SQLException e) {
			logger.error("The order was not found");
			throw new OrderException(e.getMessage());
		}
		finally {
			resultSet.close();
			preparedStatement.close();
			connection.close();
		}
		return found;
	}
}	
