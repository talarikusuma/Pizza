package com.cg.bom.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Orderbean;
import com.cg.bom.bean.Viewbean;
import com.cg.bom.connection.OrderConnection;
import com.cg.bom.exception.OrderException;

public class OrderDAO implements IOrderDAO {

	static Logger logger = Logger.getRootLogger();
	public OrderDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	}
	/*---------------------ADMIN LOGIN-----------------------*/
	@Override
	public boolean ValidLogin(Adminbean abean) throws OrderException, Exception{
		
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedstatement = null;
		ResultSet resultset = null;
		try
		{
		String username = abean.getUsername();
		String password = abean.getPassword();
		preparedstatement = connection.prepareStatement(QueryMapper.VALIDATE_ADMIN_QUERY);
		 resultset = preparedstatement.executeQuery();
		//System.out.println(rs);
		while(resultset.next())
		{
			if(resultset.getString(1).equals(username)&&resultset.getString(2).equals(password))
			{
				return true;
			}
			else
				throw new OrderException("Could not find the given credentials.");	
		}
		}
		catch(OrderException e)
		{
			//e.printStackTrace();
			logger.error("Email or password did not match");
			System.err.println(e.getMessage());
		}
		finally
		{
			resultset.close();
			preparedstatement.close();
			connection.close();
		}
		return false;
	}
	
	/*-------------------ORDER LISTING-------------------*/

	@Override
	public List<Orderbean> Listing() throws OrderException, SQLException {
		// TODO Auto-generated method stub
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedstatement = null;
		ResultSet resultset = null;
		preparedstatement = connection.prepareStatement(QueryMapper.ORDER_LISTING_QUERY);
		resultset = preparedstatement.executeQuery();
		//System.out.println(resultset);
		List<Orderbean> customlist = new ArrayList<Orderbean>();
		while(resultset.next())
		{
			Orderbean orderbean = new Orderbean();
			orderbean.setIndex(resultset.getInt(1));
			orderbean.setOrderid(resultset.getInt(2));
			orderbean.setOrderby(resultset.getString(3));
			orderbean.setBookcopies(resultset.getInt(4));
			orderbean.setTotal(resultset.getDouble(5));
			orderbean.setPaymethod(resultset.getString(6));
			orderbean.setStatus(resultset.getString(7));
			orderbean.setOrderdate(resultset.getTimestamp(8));
			customlist.add(orderbean);
			//System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
		}
			resultset.close();
			
			preparedstatement.close();
			connection.close();
		return customlist;
	}
	
	/*----------------ORDER OVERVIEW-----------------------*/
	@Override
	public Viewbean orderoverview(int orderid) throws OrderException, Exception {
		// TODO Auto-generated method stub
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedstatement = null;
		ResultSet resultset = null;
		Viewbean viewbean = null;
		try
		{
		preparedstatement = connection.prepareStatement(QueryMapper.OVERVIEW_QUERY);
		preparedstatement.setInt(1, orderid);
		resultset = preparedstatement.executeQuery();
		if(resultset.next())
		{
			viewbean = new Viewbean();
			viewbean.setOrderby(resultset.getString(1));
			viewbean.setBookcopies(resultset.getInt(2));
			viewbean.setTotal(resultset.getDouble(3));
			viewbean.setRecipientname(resultset.getString(4));
			viewbean.setRecipientnumber(resultset.getString(5));
			viewbean.setShipto(resultset.getString(6));
			viewbean.setPayment(resultset.getString(7));
			viewbean.setStatus(resultset.getString(8));
			viewbean.setOrderdate(resultset.getTimestamp(9));
		}
		else
			throw new OrderException("The order id could not be found");
		}
		catch(OrderException e)
		{
			System.err.println(e.getMessage());
			System.err.println("Retrieving the details failed!");
			logger.error(e.getMessage());
		}
		finally {
			resultset.close();
			preparedstatement.close();
			connection.close();
		}
		return viewbean;
	}

	/*----------------ORDERED BOOKS-----------------------*/

	@Override
	public List<Bookbean> orderbooks(int orderid) throws Exception {
		// TODO Auto-generated method stub
		double total=0.0;
		int totalquantity = 0;
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedstatement = null;
		ResultSet resultset = null;
		Bookbean bookbean = null;
		try
		{
		List<Bookbean> booklist = new ArrayList<Bookbean>();
		preparedstatement = connection.prepareStatement(QueryMapper.BOOK_LIST_QUERY);
		preparedstatement.setInt(1, orderid);
		resultset = preparedstatement.executeQuery();
		if(resultset!=null)
		{
		while(resultset.next())
		{
			bookbean = new Bookbean();
			bookbean.setIndex(resultset.getInt(1));
			bookbean.setBooktitle(resultset.getString(2));
			bookbean.setAuthor(resultset.getString(3));
			bookbean.setPrice(resultset.getDouble(4));
			bookbean.setQuantity(resultset.getInt(5));
			bookbean.setSubtotal(resultset.getDouble(6));
			bookbean.setTotal(total);
			booklist.add(bookbean);
			total = total+resultset.getDouble(6);
			totalquantity = totalquantity+resultset.getInt(5);
		}
		/*preparedstatement = connection.prepareStatement(QueryMapper.UPDATE_OVERVIEW_QUERY);
		preparedstatement.setDouble(1, total);
		preparedstatement.setInt(2, totalquantity);
		preparedstatement.setInt(3, orderid);
		resultset = preparedstatement.executeQuery();*/
		//System.out.println(resultset);
		preparedstatement = connection.prepareStatement(QueryMapper.UPDATE_BOOKORDER_QUERY);
		preparedstatement.setDouble(1, total);
		preparedstatement.setInt(2, totalquantity);
		preparedstatement.setInt(3, orderid);
		resultset = preparedstatement.executeQuery();
		}
		else
			throw new OrderException("Order id does not exist");
		preparedstatement.close();
		connection.close();
		resultset.close();
		return booklist;
		}
		catch(OrderException e)
		{
			logger.error("Could not add the book to list");
			System.out.println(e.getMessage());
			throw new OrderException("Retrieving the book details failed!");
		}	
		}

	/*------------------ADD BOOKS-------------------------s-*/
	@Override
	public Bookbean addbook(int orderid,int choice,Bookbean bookbean) throws Exception {
		// TODO Auto-generated method stub
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedstatement = null;
		ResultSet resultset = null;
		try{	
		preparedstatement = connection.prepareStatement("select index2,booktitle,author,price from book_list where index2=?");
		preparedstatement.setInt(1, choice);
		resultset = preparedstatement.executeQuery();
		if(resultset.next())
		{
			bookbean.setBooktitle(resultset.getString(2));
			bookbean.setAuthor(resultset.getString(3));
			bookbean.setPrice(resultset.getDouble(4));
		}
		bookbean.setSubtotal(bookbean.getPrice()*bookbean.getQuantity());
		preparedstatement = connection.prepareStatement(QueryMapper.INSERT_BOOK_QUERY);
		preparedstatement.setInt(1, orderid);
		preparedstatement.setString(2, bookbean.getBooktitle());
		preparedstatement.setString(3, bookbean.getAuthor());
		preparedstatement.setDouble(4, bookbean.getPrice());
		preparedstatement.setInt(5, bookbean.getQuantity());
		preparedstatement.setDouble(6, bookbean.getSubtotal());
		resultset = preparedstatement.executeQuery();
		if(resultset==null)
			throw new OrderException("The book could not be added.");
		}
		catch(OrderException e){
			System.out.println(e.getMessage());
			logger.error("Ordered book could not be added");
		}
		return bookbean;
	}
	
	
	@Override
	public void getbooks() throws Exception {
		// TODO Auto-generated method stub
		Connection connection = OrderConnection.getInstance().getConnection();	
		PreparedStatement preparedstatement = null;
		ResultSet resultset = null;
		try
		{
		preparedstatement = connection.prepareStatement("select index2,booktitle,author,price from book_list");
		resultset = preparedstatement.executeQuery();
		if(resultset!=null)
		{
		while(resultset.next())
		{
			System.out.println(resultset.getInt(1)+" \t"+resultset.getString(2)+" \t"+resultset.getString(3)+" "+resultset.getDouble(4));
		}
		}
		else
			throw new OrderException("Book list could not be found");
		}
		catch(OrderException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
}

	/*@Override
	public int deletebook(int orderid) throws Exception {
		// TODO Auto-generated method stub
		Connection con = Conn.getConnection(); 
		PreparedStatement preparedstatement = null;
		PreparedStatement preparedstatement1 = null;
		PreparedStatement preparedstatement2 = null;
		ResultSet rs = null;
		preparedstatement1 = con.prepareStatement("delete from order_overview where orderid=?");
		preparedstatement1.setInt(1, orderid);
		preparedstatement2 = con.prepareStatement("delete from ordered_books where orderid=?");
		preparedstatement2.setInt(1, orderid);
		preparedstatement = con.prepareStatement("delete from book_order where orderid=?");
		preparedstatement.setInt(1, orderid);
		
		
		int i = preparedstatement.executeUpdate();
		//System.out.println(i);
		return i;
	}*/
	
