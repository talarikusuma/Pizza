package com.cg.bom.dao;

public interface QueryMapper {
	
	public static final String VALIDATE_ADMIN_QUERY = "SELECT username,password FROM admin_table";
	public static final String ORDER_LISTING_QUERY = "SELECT index1,orderid,orderby,bookcopies,total,payment,status,orderdate FROM book_order";
	public static final String OVERVIEW_QUERY = "SELECT bk.orderby,bk.bookcopies,bk.total,ov.recipientname,ov.recipientnumber,ov.shipto,bk.payment,bk.status,bk.orderdate from book_order bk JOIN order_overview ov ON bk.orderid=ov.orderid where bk.orderid=?";
	public static final String BOOK_LIST_QUERY = "SELECT index1,booktitle,author,price,quantity,subtotal FROM ordered_books where orderid=?";
	public static final String INSERT_BOOK_QUERY = "INSERT INTO ordered_books VALUES(?,index1_sequence.NEXTVAL,?,?,?,?,?)";
	public static final String UPDATE_OVERVIEW_QUERY = "update order_overview set total=?,bookcopies=? where orderid=?";
	public static final String UPDATE_BOOKORDER_QUERY = "update book_order set total=?,bookcopies=? where orderid=?";

}
