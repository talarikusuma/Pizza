package com.cg.bom.dao;

public interface QueryMapper {
	
	public static final String VALIDATE_ADMIN_QUERY = "SELECT username,password FROM admin_table";
	public static final String ORDER_LISTING_QUERY = "SELECT index1,orderid,orderby,bookcopies,total,payment,status,orderdate FROM book_order";
	public static final String OVERVIEW_QUERY = "SELECT orderby,bookcopies,total,recipientname,recipientnumber,shipto,paymethod,status,orderdate FROM order_overview where orderid=?";
	public static final String BOOK_LIST_QUERY = "SELECT index1,booktitle,author,price,quantity,subtotal FROM ordered_books where orderid=?";
	public static final String INSERT_BOOK_QUERY = "INSERT INTO ordered_books VALUES(?,index1_sequence.NEXTVAL,?,?,?,?,?)";
	public static final String ADD_BOOK_QUERY = "update book_order set bookcopies=bookcopies+? where orderid=?";
	public static final String UPDATE_TOTAL_QUERY = "update book_order set total=? where orderid=?";

}
