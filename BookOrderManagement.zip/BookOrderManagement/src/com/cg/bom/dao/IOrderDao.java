package com.cg.bom.dao;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Obean;

public interface IOrderDao {
	
	//public Obean getListing(String orderid) throws Exception;
	public boolean ValidLogin(Adminbean abean) throws Exception;
	public int Listing() throws Exception;


}
