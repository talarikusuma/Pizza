package com.cg.bom.dao;

import java.util.List;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Orderbean;
import com.cg.bom.bean.Viewbean;

public interface IOrderDAO {
	
	//public Obean getListing(String orderid) throws Exception;
	public boolean ValidLogin(Adminbean adminbean) throws Exception;
	public List<Orderbean> Listing() throws Exception;
	public Viewbean orderoverview(int orderid) throws Exception;
	public List<Bookbean> orderbooks(int orderid) throws Exception;
	public Bookbean addbook(int orderid,int choice,Bookbean bookbean) throws Exception;
	public void getbooks() throws Exception;
}
