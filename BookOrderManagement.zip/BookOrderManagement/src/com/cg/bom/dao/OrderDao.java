package com.cg.bom.dao;

import java.sql.*;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Obean;
import com.cg.bom.connection.Conn;

public class OrderDao implements IOrderDao {

	@Override
	public boolean ValidLogin(Adminbean abean) throws Exception {
		
		Connection con = Conn.getConnection();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		String username = abean.getUsername();
		String password = abean.getPassword();
		ps = con.prepareStatement("select username,password from admin_table");
		 rs = ps.executeQuery();
		System.out.println(rs);
		while(rs.next())
		{
			if(rs.getString(1).equals(username)&&rs.getString(2).equals(password))
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public int Listing() throws Exception {
		// TODO Auto-generated method stub
		int count=0;
		Obean obean = new Obean();
		Connection con = Conn.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		ps = con.prepareStatement("select orderid,orderby,bookcopies from book_o");
		rs = ps.executeQuery();
		System.out.println(rs);
		if(rs.next())
		{
			obean.orderid = rs.getInt(1);
			//System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
			count++;
		}
		rs.close();
		return count;
	}

	//@Override
	/*public Obean getListing(String orderid) throws Exception {
		
		Connection con = Conn.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		rs = ps.executeQuery("select * from Order_Details");
		while(rs.next())
		{
			System.out.println(rs.getInt(1));
		}
		
		return Obean;
	}*/
	
	
	
}
