package com.cg.bom.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Obean;
import com.cg.bom.bean.Viewbean;
import com.cg.bom.connection.Conn;

public class OrderDao implements IOrderDao {

	@Override
	public boolean ValidLogin(Adminbean abean) throws Exception {
		
		Connection con = Conn.getConnection();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		String username = abean.getUsername();
		String password = abean.getPassword();
		ps = con.prepareStatement("select username,password from admin_table");
		 rs = ps.executeQuery();
		System.out.println(rs);
		while(rs.next())
		{
			if(rs.getString(1).equals(username)&&rs.getString(2).equals(password))
			{
				return true;
			}
		}
		rs.close();
		return false;
	}

	@Override
	public List<Obean> Listing() throws Exception {
		// TODO Auto-generated method stub
		int count=0;
		
		Connection con = Conn.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		ps = con.prepareStatement("select index1,orderid,orderby,bookcopies,total,payment,status,orderdate from book_order");
		rs = ps.executeQuery();
		System.out.println(ps);
		List<Obean> customlist = new ArrayList<Obean>();
		while(rs.next())
		{
			Obean obean = new Obean();
			obean.setIndex(rs.getInt(1));
			obean.setOrderid(rs.getInt(2));
			obean.setOrderby(rs.getString(3));
			obean.setBookcopies(rs.getInt(4));
			obean.setTotal(rs.getDouble(5));
			obean.setPaymethod(rs.getString(5));
			obean.setStatus(rs.getString(7));
			obean.setOrderdate(rs.getTimestamp(8));
			customlist.add(obean);
			//System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
			count++;
		}
		rs.close();
		return customlist;
	}

	@Override
	public Viewbean orderoverview(int orderid) throws Exception {
		// TODO Auto-generated method stub
		Connection con = Conn.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Viewbean vbean = null;
		ps = con.prepareStatement("select orderby,bookcopies,total,recipientname,recipientnumber,shipto,payment,status,orderdate from order_overview where orderid=?");
		ps.setInt(1, orderid);
		rs = ps.executeQuery();
		if(rs.next())
		{
			vbean = new Viewbean();
			vbean.setOrderby(rs.getString(1));
			vbean.setBookcopies(rs.getInt(2));
			vbean.setTotal(rs.getDouble(3));
			vbean.setRecipientname(rs.getString(4));
			vbean.setRecipientnumber(rs.getString(5));
			vbean.setShipto(rs.getString(6));
			vbean.setPayment(rs.getString(7));
			vbean.setStatus(rs.getString(8));
			vbean.setOrderdate(rs.getTimestamp(9));
		}
		return vbean;
	}

	@Override
	public Bookbean orderbooks(int orderid) throws Exception {
		// TODO Auto-generated method stub
		Connection con = Conn.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Bookbean bbean = null;
		ps = con.prepareStatement("select index1,booktitle,author,price,quantity,subtotal from ordered_books where orderid=?");
		ps.setInt(1, orderid);
		rs = ps.executeQuery();
		if(rs.next())
		{
			bbean = new Bookbean();
			bbean.setIndex(rs.getInt(1));
			bbean.setBooktitle(rs.getString(2));
			bbean.setAuthor(rs.getString(3));
			bbean.setPrice(rs.getDouble(4));
			bbean.setQuantity(rs.getInt(5));
			bbean.setSubtotal(rs.getDouble(6));
		}
		return bbean;
	}

	@Override
	public String addbook(int orderid,Bookbean bbean) throws Exception {
		// TODO Auto-generated method stub
		Connection con = Conn.getConnection();
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		ResultSet rs = null;
		String booktitle="";
		//Bookbean bbean =new Bookbean();
		ps = con.prepareStatement("insert into ordered_books values(?,index1_sequence.NEXTVAL,?,?,?,?,?)");
		ps.setInt(1, orderid);
		
		ps.setString(2, bbean.getBooktitle());
		ps.setString(3, bbean.getAuthor());
		ps.setDouble(4, bbean.getPrice());
		ps.setInt(5, bbean.getQuantity());
		ps.setDouble(6, bbean.getSubtotal());
		
		int i = ps.executeUpdate();
		System.out.println(i);
		if(i==1)
		{
			ps1  = con.prepareStatement("update book_order set bookcopies=bookcopies+1 where orderid=?");
			ps1.setInt(1, orderid);
			ps1.executeUpdate();
			booktitle = bbean.getBooktitle();
			return booktitle;
		}
		else
			return "The book could not be added!!";
	}

	@Override
	public int deletebook(int orderid) throws Exception {
		// TODO Auto-generated method stub
		Connection con = Conn.getConnection();
		PreparedStatement ps = null;
		/*PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;*/
		ResultSet rs = null;
		ps = con.prepareStatement("delete a,b from book_order c,order_overview a,ordered_books b where a.orderid=c.orderid AND b.orderid=?");
		/*ps1 = con.prepareStatement("delete from order_overview where orderid=?");
		ps2 = con.prepareStatement("delete from ordered_books where orderid=?");*/
		ps.setInt(1, orderid);
		/*ps1.setInt(1, orderid);
		ps2.setInt(1, orderid);*/
		int i = ps.executeUpdate();
		//System.out.println(i);
		return i;
	}

	
	
	
	
}
