package com.cg.bom.service;

import com.cg.bom.bean.Adminbean;

public interface IOrderService {
	
	public boolean ValidLogin(Adminbean abean) throws Exception;
	public int Listing() throws Exception;

}
