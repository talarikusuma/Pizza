package com.cg.bom.service;

import java.util.List;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.BookListbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Orderbean;
import com.cg.bom.bean.Viewbean;

public interface IOrderService {
	
	public boolean ValidLogin(Adminbean adminbean) throws Exception;
	public List<Orderbean> Listing() throws Exception;
	public Viewbean orderoverview(int orderid) throws Exception;
	public List<Bookbean> orderbooks(int orderid) throws Exception;
	public boolean findorder(int orderid) throws Exception;
	public List<BookListbean> getbooks() throws Exception;
	public Bookbean addbook(int orderid,int choice,Bookbean bookbean) throws Exception;
	public int deletebook(int orderid) throws Exception;
}
