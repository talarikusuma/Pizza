package com.cg.bom.service;

import java.util.List;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Obean;
import com.cg.bom.bean.Viewbean;

public interface IOrderService {
	
	public boolean ValidLogin(Adminbean abean) throws Exception;
	public List<Obean> Listing() throws Exception;
	public Viewbean orderoverview(int orderid) throws Exception;
	public Bookbean orderbooks(int orderid) throws Exception;
	public String addbook(int orderid,Bookbean bbean) throws Exception;
	public int deletebook(int orderid) throws Exception;
}
