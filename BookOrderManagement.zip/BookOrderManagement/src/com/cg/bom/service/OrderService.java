package com.cg.bom.service;

import java.util.List;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Obean;
import com.cg.bom.bean.Viewbean;
import com.cg.bom.dao.OrderDao;

public class OrderService implements IOrderService{
	
	OrderDao dao = new OrderDao();

	@Override
	public boolean ValidLogin(Adminbean abean) throws Exception {
		// TODO Auto-generated method stub
		boolean valid = dao.ValidLogin(abean);
		return valid;
	}

	@Override
	public List<Obean> Listing() throws Exception {
		// TODO Auto-generated method stub
		OrderDao dao = new OrderDao();
		List<Obean> ncustom = dao.Listing();
		return ncustom;
	}

	@Override
	public Viewbean orderoverview(int orderid) throws Exception {
		// TODO Auto-generated method stub
		OrderDao dao = new OrderDao();
		Viewbean vbean = dao.orderoverview(orderid);
		return vbean;
	}

	@Override
	public Bookbean orderbooks(int orderid) throws Exception {
		// TODO Auto-generated method stub
		OrderDao dao = new OrderDao();
		Bookbean bbean = dao.orderbooks(orderid);
		return bbean;
	}

	@Override
	public String addbook(int orderid,Bookbean bbean) throws Exception {
		// TODO Auto-generated method stub
		OrderDao dao = new OrderDao();
		String order = dao.addbook(orderid,bbean);
		return order;
	}

	@Override
	public int deletebook(int orderid) throws Exception {
		// TODO Auto-generated method stub
		OrderDao dao = new OrderDao();
		int delete = dao.deletebook(orderid);
		return delete;
	}

	
	

}
