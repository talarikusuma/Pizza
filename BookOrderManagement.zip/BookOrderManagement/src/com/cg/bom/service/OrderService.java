 package com.cg.bom.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Orderbean;
import com.cg.bom.bean.Viewbean;
import com.cg.bom.dao.OrderDao;
import com.cg.bom.exception.OrderException;

public class OrderService implements IOrderService{
	
	OrderDao dao = new OrderDao();

	/*---------------------ADMIN LOGIN-----------------------*/
	@Override
	public boolean ValidLogin(Adminbean adminbean) throws Exception {
		// TODO Auto-generated method stub
		boolean valid;
		try
		{
			String emailpattern = "^[a-zA-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";
			String passwordpattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$^+=!*()@%&]).{6,10}$";
			if (!Pattern.matches(emailpattern, adminbean.getUsername()))
			{
				valid = false;
				throw new OrderException("Please enter a valid email.Ex:computer@abc.com");
			}
			if(!Pattern.matches(passwordpattern, adminbean.getPassword())) {
				valid = false;
				throw new OrderException("Password must contain atleast one uppercase letter,one lowercase letter,one symbol with 8-10 characters");
			}
		}
		catch(OrderException e)
		{
			System.out.println(e.getMessage());
		}
		valid = dao.ValidLogin(adminbean);
		return valid;
	}
	
	/*-------------------ORDER LISTING-------------------*/
	@Override
	public List<Orderbean> Listing() throws Exception {
		// TODO Auto-generated method stub
		OrderDao dao = new OrderDao();
		List<Orderbean> ncustom = dao.Listing();
		return ncustom;
	}

	/*----------------ORDER OVERVIEW-----------------------*/
	@Override
	public Viewbean orderoverview(int orderid) throws Exception {
		// TODO Auto-generated method stub
		OrderDao dao = new OrderDao();
		Viewbean viewbean = dao.orderoverview(orderid);
		return viewbean;
	}

	/*----------------ORDERED BOOKS-----------------------*/
	@Override
	public List<Bookbean> orderbooks(int orderid) throws Exception {
		// TODO Auto-generated method stub
		OrderDao dao = new OrderDao();
		List<Bookbean> bookbean = dao.orderbooks(orderid);
		return bookbean;
	}

	/*------------------ADD BOOKS-------------------------s-*/
	@Override
	public String addbook(int orderid,Bookbean bookbean) throws Exception {
		// TODO Auto-generated method stub
		OrderDao dao = new OrderDao();
		String order = dao.addbook(orderid,bookbean);
		return order;
	}

	/*@Override
	public int deletebook(int orderid) throws Exception {
		// TODO Auto-generated method stub
		OrderDao dao = new OrderDao();
		int delete = dao.deletebook(orderid);
		return delete;
	}*/

	
	

}
