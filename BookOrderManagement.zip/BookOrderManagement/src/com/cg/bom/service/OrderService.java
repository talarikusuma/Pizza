package com.cg.bom.service;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.dao.OrderDao;

public class OrderService implements IOrderService{
	
	OrderDao dao = new OrderDao();

	@Override
	public boolean ValidLogin(Adminbean abean) throws Exception {
		// TODO Auto-generated method stub
		boolean valid = dao.ValidLogin(abean);
		return valid;
	}

	@Override
	public int Listing() throws Exception {
		// TODO Auto-generated method stub
		int ncustom = dao.Listing();
		return ncustom;
	}

	
	

}
