package com.cg.bom.bean;

import java.sql.Timestamp;

public class Viewbean {
	
	/*int orderid;
	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}*/
	String orderby;
	int bookcopies;
	double total;
	String recipientname;
	String recipientnumber;
	String shipto;
	String payment;
	String status;
	Timestamp orderdate;
	
	@Override
	public String toString() {
		return "---------------ORDER OVERVIEW--------------"
				+"\n-----------------------------------------"
				+ " \nOrderby\t\t|" + orderby + "\nBookcopies\t|" + bookcopies + "\nTotal\t\t|" + total + "\nRecipient name\t|"
				+ recipientname + "\nRecipient number|" + recipientnumber + "\nShipto\t\t|" + shipto + "\nPayment\t\t|" + payment
				+ "\nStatus\t\t|" + status + "\nOrderdate\t|" + orderdate;
	}
	
	public String getOrderby() {
		return orderby;
	}
	public void setOrderby(String orderby) {
		this.orderby = orderby;
	}
	public int getBookcopies() {
		return bookcopies;
	}
	public void setBookcopies(int bookcopies) {
		this.bookcopies = bookcopies;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public String getRecipientname() {
		return recipientname;
	}
	public void setRecipientname(String recipientname) {
		this.recipientname = recipientname;
	}
	public String getRecipientnumber() {
		return recipientnumber;
	}
	public void setRecipientnumber(String recipientnumber) {
		this.recipientnumber = recipientnumber;
	}
	public String getShipto() {
		return shipto;
	}
	public void setShipto(String shipto) {
		this.shipto = shipto;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Timestamp getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(Timestamp orderdate) {
		this.orderdate = orderdate;
	}

}
