package com.cg.bom.bean;

import java.sql.Date;
import java.sql.Timestamp;

public class Obean {
	
	public int index;
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}

	public int orderid;
	String orderby;
	int bookcopies;
	double total;
	String paymethod;
	String status;
	Timestamp orderdate;
	
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public String getOrderby() {
		return orderby;
	}
	public void setOrderby(String orderby) {
		this.orderby = orderby;
	}
	public int getBookcopies() {
		return bookcopies;
	}
	public void setBookcopies(int bookcopies) {
		this.bookcopies = bookcopies;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public String getPaymethod() {
		return paymethod;
	}
	public void setPaymethod(String paymethod) {
		this.paymethod = paymethod;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Timestamp getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(Timestamp timestamp) {
		this.orderdate = timestamp;
	}
	@Override
	public String toString() {
		return "Book Order Table [index=" + index + ", orderid=" + orderid + ", orderby=" + orderby + ", bookcopies=" + bookcopies
				+ ", total=" + total + ", paymethod=" + paymethod + ", status=" + status + ", orderdate=" + orderdate
				+ "]";
	}
	
	

}
