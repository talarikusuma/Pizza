package com.cg.bom.bean;

public class Bookbean {
	
	@Override
	public String toString() {
		return "Bookbean [index=" + index + ", booktitle=" + booktitle + ", author=" + author + ", price=" + price
				+ ", quantity=" + quantity + ", subtotal=" + subtotal + "]";
	}
	int index;
	String booktitle;
	String author;
	double price;
	int quantity;
	double subtotal;
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getBooktitle() {
		return booktitle;
	}
	public void setBooktitle(String booktitle) {
		this.booktitle = booktitle;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}
	
}
