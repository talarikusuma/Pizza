package com.cg.bom.controller;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.BookListbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Orderbean;
import com.cg.bom.bean.Viewbean;
import com.cg.bom.exception.OrderException;
import com.cg.bom.service.IOrderService;
import com.cg.bom.service.OrderService;

public class OrderMain {

	static Logger logger = Logger.getRootLogger();
	static Scanner scanner = new Scanner(System.in);
	
	
	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
		int orderId,choice,bookChoice,quantity;
		int checkId=0,chooseException=0;
		boolean choiceException=true;
		String decide="yes";
		Adminbean adminbean = new Adminbean();
		System.out.println("Admin Login");
		System.out.println("Enter email:");
		String username = scanner.nextLine();
		adminbean.setUsername(username);
		System.out.println("Enter password:");
		String password = scanner.nextLine();
		adminbean.setPassword(password);
		
		IOrderService orderservice = new OrderService();
		boolean valid = orderservice.ValidLogin(adminbean);
		//System.out.println(valid);
		
		try{
			
		/*---------------ORDER MANAGEMENT--------------*/
		if(valid){
			System.out.println("Successfully logged in!");
			logger.info("Successfully logged in!");
			System.out.println("Welcome "+adminbean.getUsername());
			do {
				do {
					try {
						
					chooseException=0;
			/*---------------Display after login------------------*/
			System.out.println("Select the required option:");
			System.out.println("1.List Orders");
			System.out.println("2.Details");
			System.out.println("3.Add books");
			System.out.println("4.Delete books");
			System.out.println("5.Exit");
		
			Scanner scanner = new Scanner(System.in);
			choice = scanner.nextInt();
			choiceException=false;
			switch(choice){
			case 1:
				
				/*-------------------ORDER LISTING-------------------*/
				
				System.out.println("/*---------------------------------------Book order Management------------------------------------------*/");
				System.out.println("-------------------------------------------Book Order Table----------------------------------------------");
				System.out.println("Index  Orderid  Orderby  \tBookcopies \tTotal \tPaymethod\t\t Status\t\t Orderdate");
				System.out.println("---------------------------------------------------------------------------------------------------------");
				
				try {
				List<Orderbean> customlist = new ArrayList<Orderbean>();
				customlist = orderservice.Listing();
				if(!customlist.isEmpty()){
					logger.info("Ordered list is displayed");
					Iterator<Orderbean> i = customlist.iterator();
					while(i.hasNext()){
						System.out.println(i.next());
					}
				}
				else {
					scanner.close();
					logger.error("Ordered list could not be found");
					throw new OrderException("There are no orders..");
				}
				}
				catch(OrderException e){
					logger.error(e.getMessage());
					System.err.println(e.getMessage());
				}
				break;
			
				/*----------------ORDER DETAILS-----------------------*/
			case 2:
				
				do {
					checkId=0;
				System.out.println("Enter the order id to get details:");
				scanner = new Scanner(System.in);
				try{
				orderId = scanner.nextInt();
				Viewbean viewbean = new Viewbean();
				List<Bookbean> booklist = new ArrayList<Bookbean>();
				booklist = orderservice.orderbooks(orderId);
				viewbean = orderservice.orderoverview(orderId);
				
					if(booklist.isEmpty()||viewbean==null){
						scanner.close();
						logger.error("Order details could not  be found");
						throw new OrderException("Orderview List not found");
					}
					else
					{
						System.out.println(viewbean);
						System.out.println("\n");
						if(booklist!=null){
							System.out.println("--------------------------------Book Order Details------------------------------------");
							System.out.println("Index\tBooktitle\t\tAuthor\t\t\tPrice\t\tQuantity\tSubtotal ");
							System.out.println("-------------------------------------------------------------------------------------------------------------------------");
							
							Iterator<Bookbean> ibooklist = booklist.iterator();
							while(ibooklist.hasNext()){
								System.out.println(ibooklist.next());
							}
						}
						System.out.println("Total:"+viewbean.getBookcopies()+" "+viewbean.getTotal());
						logger.info("The ordered details are displayed");
						
					}
				}
				
				catch(OrderException e){
					logger.error("Could not find the order details!");
					System.err.println(e.getMessage());
					System.err.println("Retrieving the details failed!");
					logger.error(e.getMessage());
					
				}
				catch (InputMismatchException e) {
					System.err.println("Please enter a numeric value, try again");
					logger.error("Entered a character or string.");
					checkId=1;
				}
				}while(checkId==1);
				break;
			
				/*---------------ADD BOOKS----------------------------*/
			case 3:	
				Bookbean bookbean = new Bookbean();
				
				List<BookListbean> bookcatalog = new ArrayList<BookListbean>();
				do {
					checkId=1;
					System.out.print("Enter the order id to add books:");
					scanner = new Scanner(System.in);
				try {
				
				orderId = scanner.nextInt();
				boolean findid = orderservice.findorder(orderId);
				//System.out.println(findid);
				
				if(findid){
				System.out.println("Select the book to add:");
				bookcatalog=orderservice.getbooks();
					if(bookcatalog!=null){
						System.out.println("------------------Book Catalog-------------------");
						System.out.println("Index\tBooktitle\t\tAuthor\t\tPrice ");
						Iterator<BookListbean> ibooklist = bookcatalog.iterator();
						while(ibooklist.hasNext()){
							System.out.println(ibooklist.next());
						}
					}
					else{
						logger.info("Book list could not be found");
						scanner.close();
						throw new OrderException("Book list not found!");
					}
				}
				else{
					logger.error("The ordered books could not be found");
					scanner.close();
					throw new OrderException("The book order "+orderId+" not found");
				}
				
				
				/*------------ADD BOOK SUCCESS MESSAGE---------------*/
				//scanner = new Scanner(System.in);
				bookChoice = scanner.nextInt();
				System.out.print("Enter the quantity of books:");
				quantity = scanner.nextInt();
				
				bookbean.setQuantity(quantity);
				
				bookbean = orderservice.addbook(orderId,bookChoice,bookbean);
				if(bookbean.getBooktitle()!=null){
					System.out.println("The book '"+bookbean.getBooktitle()+"' has been added to order id "+orderId);
					logger.info("The book with given order id is added");
				}
				else{
					logger.error("The book could not be added");
					scanner.close();
					throw new OrderException("The book could not be added.");
				}
				
				}
				catch(OrderException e){
					System.out.println(e.getMessage());
					logger.error("Ordered book could not be added");
				}
				catch(InputMismatchException e)
				{
					System.err.println("Please enter a numeric value, try again");
					logger.error("Entered a character or string.");
					checkId=0;
				}
				}while(checkId==0);
				break;
				
			/*----------------DELETE BOOKS---------------------------*/
				
			case 4:
				do {
					System.out.print("Enter the order id to delete books:");
					
					checkId=1;
				try {
					scanner = new Scanner(System.in);
				orderId = scanner.nextInt();
				int deleted = orderservice.deletebook(orderId);
				if(deleted==1)
					System.out.println("The order "+orderId+" has been deleted! "+deleted);
				else{
					scanner.close();
					throw new OrderException("The order id could not be deleted!");
				}
				}
				
				catch(InputMismatchException e)
				{
					checkId=0;
					System.err.println("Please enter a numeric value, try again");
					logger.error("Entered a character or string.");
					
				}
				catch(OrderException e) {
					System.err.println(e.getMessage());
					logger.error(e.getMessage());
				}
				}while(checkId==0);
				
				break;
				
			case 5:
				logger.info("Closed application");
				System.out.println("Closing Application");
				System.exit(0);
			default:
				System.err.println("Please enter a valid choice..");
				logger.error("Invalid choice");
			}
			}
			catch(InputMismatchException e){
				System.err.println("Please enter a numeric value, try again");
				logger.error("Entered a character or string.");
				chooseException=1;
			}
			}while(chooseException==1);	
				
			do {
				try {
			System.out.println("Do you want to continue the application?(yes/no):");
			decide = scanner.next();
			if(decide.equals("no")){
				System.out.println("Closing Application");
				System.exit(0);
			}
			else if(decide.equals("yes"))
			{
				choiceException=true;
			}
			else
				throw new OrderException("Please enter only yes or no");
			}
			catch (InputMismatchException e) {
				System.err.println("Please enter a numeric value, try again");
				logger.error("Entered a character or string.");
				choiceException=false;
			}
			catch(OrderException e)
			{
				System.err.println(e.getMessage());
			}
			}while(!decide.equals("yes")&&!decide.equals("no"));
			
			
			}while(choiceException);
			}
				
			//scanner.close();
		else{
			System.err.println("Enter a valid username or password..");
			main(null);	
			throw new OrderException("Could not find the given credentials.");	
		}
		}
	
		catch(OrderException e){
			//e.printStackTrace();
			logger.error("Email or password did not match");
			System.err.println(e.getMessage());
		}
	}
	}


		
