package com.cg.bom.controller;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Orderbean;
import com.cg.bom.bean.Viewbean;
import com.cg.bom.exception.OrderException;
import com.cg.bom.service.IOrderService;
import com.cg.bom.service.OrderService;

public class OrderMain {

	static Logger logger = Logger.getRootLogger();
	
	//@SuppressWarnings("resource")
	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
		Scanner scanner = new Scanner(System.in);
		int orderid,choice,bookchoice,qty;
		String decide;
		Adminbean adminbean = new Adminbean();
		System.out.println("Admin Login");
		System.out.println("Enter email:");
		String username = scanner.nextLine();
		adminbean.setUsername(username);
		System.out.println("Enter password:");
		String password = scanner.nextLine();
		adminbean.setPassword(password);
		IOrderService orderservice = new OrderService();
		boolean valid = orderservice.ValidLogin(adminbean);
		System.out.println(valid);
		
		/*---------------ORDER MANAGEMENT--------------*/
		if(valid){
			System.out.println("Successfully logged in!");
			System.out.println("Welcome "+adminbean.getUsername());
			
			/*---------------Display after login------------------*/
			while(true){
			System.out.println("Select the required option:");
			System.out.println("1.List Orders");
			System.out.println("2.Details");
			System.out.println("3.Add books");
			System.out.println("4.Exit");
			//System.out.println("3.Delete");
			try
			{
			choice = scanner.nextInt();
			switch(choice){
			case 1:
				
				/*-------------------ORDER LISTING-------------------*/
				
				System.out.println("/*-------------------Book order Management------------------------*/");
				System.out.println("--------------------Book Order Table-------------------");
				System.out.println("Index  Orderid  Orderby  \tBookcopies \tTotal \tPaymethod\t\t Status\t\t Orderdate");
				try {
				List<Orderbean> customlist = new ArrayList<Orderbean>();
				customlist = orderservice.Listing();
				if(!customlist.isEmpty()){
					Iterator<Orderbean> i = customlist.iterator();
					while(i.hasNext()){
						System.out.println(i.next());
					}
				}
				else {
					throw new OrderException("There are no orders..");
				}
				}
				catch(OrderException e)
				{
					logger.error(e.getMessage());
					System.err.println(e.getMessage());
				}
				break;
			
				/*----------------ORDER DETAILS-----------------------*/
			case 2:
				System.out.println("Enter the order id to get details:");
				orderid = scanner.nextInt();
				Viewbean viewbean = new Viewbean();
				List<Bookbean> booklist = new ArrayList<Bookbean>();
				booklist = orderservice.orderbooks(orderid);
				viewbean = orderservice.orderoverview(orderid);
				try{
					if(booklist.isEmpty()||viewbean==null)
						throw new OrderException("Orderview List not found");
					else
					{
						System.out.println(viewbean);
						System.out.println("\n");
						if(booklist!=null){
							System.out.println("------------------Book Order Details--------------");
							System.out.println("Index\tBooktitle\t\tAuthor\t\tPrice\tQuantity\tSubtotal ");
							Iterator<Bookbean> ibooklist = booklist.iterator();
							while(ibooklist.hasNext()){
								System.out.println(ibooklist.next());
							}
						}
						System.out.println("Total:"+viewbean.getBookcopies()+" "+viewbean.getTotal());
					}
				}
				catch(OrderException e){
					logger.error("Could not find the order details!");
					System.err.println(e.getMessage());
				}
				
				
				break;
			
				/*---------------ADD BOOKS----------------------------*/
			case 3:	
				Bookbean bookbean = new Bookbean();
				System.out.print("Enter the order id to add books:");
				orderid = scanner.nextInt();
				System.out.println("Select the book to add:");
				orderservice.getbooks();
				
				/*------------ADD BOOK SUCCESS MESSAGE---------------*/
				
				bookchoice = scanner.nextInt();
				System.out.print("Enter the quantity of books:");
				qty = scanner.nextInt();
				//System.out.println(subtotal);
				System.out.print("Do you want add the book/s yes/no:");
				decide = scanner.next();
				if(decide.equals("yes")){ 
					bookbean.setQuantity(qty);
					//bookbean.setSubtotal(subtotal);
				bookbean = orderservice.addbook(orderid,bookchoice,bookbean);
				System.out.println("The book '"+bookbean.getAuthor()+"' has been added to order id "+orderid);
				}
				break;
				
			/*case 5:
				System.out.print("Enter the order id to delete books:");
				int orderid2 = scanner.nextInt();
				System.out.print("Do you want delete the order yes/no:");
				decide = scanner.next();
				if(decide.equals("yes"))
				{
				int deleted = se.deletebook(orderid2);
				System.out.println("The order "+order id2+" has been deleted! "+deleted);
				}
				break;*/
			case 4:
				System.out.println("Closing Application");
				System.exit(0);
			default:
				System.err.println("Please enter a valid choice..");
				logger.error("Invalid choice");
			}
			}
			catch (InputMismatchException e) {
				scanner.nextLine();
				System.err.println("Please enter a numeric value, try again");
				logger.error("Entered a character or string.");
			}
		}
		}
		else
		{
			System.out.println("Enter a valid username or password..");
			main(null);	
		}
		scanner.close();
	}

}
