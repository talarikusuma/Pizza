package com.cg.bom.connection;

import java.sql.*;

public class Conn {

	public static Connection getConnection() throws ClassNotFoundException {
		try {
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","9999");
			  System.out.println("connected....");
			  return conn;
			  }
			  
			  catch(SQLException e)
			  {
				  System.out.println(e);
				  
			  }
			 // DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg628", "training628");
			
		return null;
	}

}
