package com.cg.bom.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.bean.Obean;
import com.cg.bom.bean.Viewbean;
import com.cg.bom.service.OrderService;

public class OrderMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String ch;
		int orderid;
		String booktitle;
		Obean obean = new Obean();
		Adminbean abean = new Adminbean();
		System.out.println("Admin Login");
		System.out.println("Enter username:");
		String username = sc.nextLine();
		abean.setUsername(username);
		System.out.println("Enter password:");
		String password = sc.nextLine();
		abean.setPassword(password);
		OrderService os = new OrderService();
		boolean valid = os.ValidLogin(abean);
		System.out.println(valid);
		if(valid)
		{
			
			System.out.println("logged in");
			System.out.println("------Book order Management-----------");
			List<Obean> customlist = new ArrayList<Obean>();
			customlist = os.Listing();
			if(customlist!=null)
			{
				Iterator<Obean> i = customlist.iterator();
				while(i.hasNext())
				{
					System.out.println(i.next());
				}
				
			}
			System.out.println("Select the required option:");
			System.out.println("1.Details");
			System.out.println("2.Add books");
			System.out.println("3.Delete");
			int choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter the order id to get details:");
				orderid = sc.nextInt();
				Viewbean vbean = new Viewbean();
				Bookbean bbean = new Bookbean();
				//vbean.setOrderid(orderid);
				vbean = os.orderoverview(orderid);
				bbean = os.orderbooks(orderid);
				System.out.println(vbean);
				System.out.println(bbean);
				break;
			case 2:
				System.out.print("Enter the order id to add books:");
				orderid = sc.nextInt();
				System.out.println("Select the book to add");
				System.out.println("1.Head First Java-Kathy Sierra");
				System.out.println("2.Looking for Alaska-Jeff Green");
				System.out.println("3.Marvel-Stanley");
				System.out.println("4.Harry Potter-J.K Rowling");
				int chbook = sc.nextInt();
				System.out.print("Enter the quantity of books:");
				int qty = sc.nextInt();
				Bookbean bbean1 = new Bookbean();
				switch(chbook)
				{
				case 1:
					bbean1.setBooktitle("Head First Java");
					bbean1.setAuthor("Sierra");
					bbean1.setPrice(35.70);
					break;
				case 2:
					bbean1.setBooktitle("Looking for Alaska");
					bbean1.setAuthor("Jeff Green");
					bbean1.setPrice(55.71);
					break;
				case 3:
					bbean1.setBooktitle("Marvel");
					bbean1.setAuthor("Stanley");
					bbean1.setPrice(46.82);
					break;
				case 4:
					bbean1.setBooktitle("Harry Potter");
					bbean1.setAuthor("J.K Rowling");
					bbean1.setPrice(56.34);
					break;
				default:
					System.out.println("Enter a book in the list");
				}
				bbean1.setQuantity(qty);
				double st = bbean1.getPrice()*qty;
				bbean1.setSubtotal(st);
				
				//System.out.println(bbean1);
				System.out.print("Do you want add the book/s yes/no:");
				ch = sc.next();
				if(ch=="yes")
				{
				booktitle = os.addbook(orderid,bbean1);
				System.out.println("The book '"+booktitle+"' has been added to order id "+orderid);
				}
				break;
			case 3:
				System.out.print("Enter the order id to delete books:");
				int orderid2 = sc.nextInt();
				System.out.print("Do you want delete the order yes/no:");
				ch = sc.next();
				if(ch.equals("yes"))
				{
				int deleted = os.deletebook(orderid2);
				System.out.println("The order "+orderid2+" has been deleted! "+deleted);
				}
				break;
			default:
				System.out.println("Enter a valid choice..");
			}
		}
		else
			System.out.println("Enter a valid username or password..");

	}

}
