package com.cg.bom.ui;

import java.util.Scanner;

import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Obean;
import com.cg.bom.service.OrderService;

public class OrderMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Obean obean = new Obean();
		Adminbean abean = new Adminbean();
		
		System.out.println("Admin Login");
		System.out.println("Enter username:");
		String username = sc.nextLine();
		abean.setUsername(username);
		System.out.println("Enter password:");
		String password = sc.nextLine();
		abean.setPassword(password);
		OrderService os = new OrderService();
		boolean valid = os.ValidLogin(abean);
		System.out.println(valid);
		if(valid)
		{
			System.out.println("logged in");
			System.out.println("------Book order Management-----------");
			int ncustom = os.Listing();
			System.out.println(ncustom);
		}
		else
			System.out.println("Enter a valid username or password..");

	}

}
