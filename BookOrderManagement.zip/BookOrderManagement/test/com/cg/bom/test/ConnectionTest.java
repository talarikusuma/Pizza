package com.cg.bom.test;

import java.sql.Connection;

import static org.junit.Assert.assertNotNull;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bom.connection.OrderConnection;
import com.cg.bom.dao.OrderDAO;
import com.cg.bom.exception.OrderException;


class ConnectionTest {

	static OrderDAO daotest;
	static OrderConnection connectTest;
	
	@BeforeClass
	public static void initialise() {
		daotest = new OrderDAO();
		connectTest = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}
	
	/**
	 * Test case for Establishing Connection
	 * 
	 * @throws OrderException
	 **/
	@Test
	public void test() throws OrderException {
		Connection connectTest = OrderConnection.getInstance().getConnection();
		assertNotNull(connectTest);
	}
	
	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daotest = null;
		connectTest = null;
	}


}
