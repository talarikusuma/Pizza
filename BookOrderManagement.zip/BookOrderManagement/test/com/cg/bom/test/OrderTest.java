package com.cg.bom.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.bom.exception.OrderException;

class OrderTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

	@Test
	void testValidLogin() throws OrderException
	{
		
	}
}
