package com.cg.bom.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import com.cg.bom.bean.Adminbean;
import com.cg.bom.bean.Bookbean;
import com.cg.bom.dao.OrderDAO;
import com.cg.bom.exception.OrderException;

class OrderTest {
	
	static OrderDAO dao = null;
	static Adminbean adminbean;
	static Bookbean bookbean = null;
	
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		
	}
	

	@Test
	void testValidLogin() throws OrderException
	{	
		adminbean = new Adminbean();
		dao = new OrderDAO();
		adminbean.setUsername("capgem@gmail.com");
		adminbean.setPassword("Capgem@123");
		assertEquals(true,dao.ValidLogin(adminbean));
	}
	
	@Test
	void testListing() throws OrderException
	{
		assertNotNull(dao.Listing());
	}
	
	@Test
	void testOrderoverview() throws OrderException
	{
		dao = new OrderDAO();
		assertNotNull(dao.orderoverview(43));
	}

	@Test
	void testOrderbooks() throws OrderException
	{
		dao = new OrderDAO();
		assertNotNull(dao.orderbooks(45));
	}
	
	@Test
	void testAddbook() throws OrderException
	{
		bookbean = new Bookbean();
		bookbean.setQuantity(1);	
		dao = new OrderDAO();
		assertNotNull(dao.addbook(44, 1, bookbean));
	}
	
	@Test
	void testDeletebook() throws OrderException
	{
		dao = new OrderDAO();
		assertEquals(1,dao.deletebook(44));
	}
	
}
