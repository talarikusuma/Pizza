package com.capgemini.pizzaorder.service;

public class PizzaOrderService implements IPizzaOrderService
{

}
