import org.junit.Test;

/*public class Testing {
	@Test
	public void testGetFullName() {
		System.out.println("from test person");
		Person per=new Person("robert","king");
		assertEquals("robert king",per.getFullName());
	}
	@Test
	public void testNullIsInName() {
		System.out.println("from test person");
		Person per1=new Person("robert","king");
		assertNotNull("full name null",per1.getFullName());
		assertNotNull("First name null",per1.getFirstName());
		assertNotNull("last name null",per1.getLastName());
		
	}
	@Test
	
	public void testGetFirstName() {
		Person p=new Person("robert","king");
		assertEquals(p.getFirstName(),"robert");
	}
	@Test
	public void testGetLastName() {
		Person p1=new Person("robert","king");
		assertEquals(p1.getLastName(),"king");
	}


}*/
